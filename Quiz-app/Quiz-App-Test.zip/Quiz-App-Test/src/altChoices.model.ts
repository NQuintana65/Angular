export interface altChoice
 {
    id: string;
    text: string;
 }
 